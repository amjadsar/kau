-  main.yml: installs nginx and will enable the basic nginx configuration for
   version introspection
