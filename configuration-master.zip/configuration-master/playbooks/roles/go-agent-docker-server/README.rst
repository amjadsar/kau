In order to use this role you must use a specific set of AMIs
#############################################################

`This role is for use with the AWS ECS AMIs listed here`_

.. _This role is for use with the AWS ECS AMIs listed here: https://docs.aws.amazon.com/AmazonECS/latest/developerguide/launch_container_instance.html
