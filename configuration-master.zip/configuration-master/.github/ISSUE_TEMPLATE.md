GitHub issues are not meant for support questions. Please use the 
[mailing list](https://groups.google.com/forum/#!forum/openedx-ops)
or [Slack channels](https://open.edx.org/blog/open-edx-slack) to get help.

Please open issues here to report bugs in the ansible scripts themselves.

When reporting an issue, please include the following information.

If `/edx/bin/show-repo-heads` is available on your system, it can provide much of this information:

- Configuration ref:
- edx-platform ref:
- other refs:

#Steps to replicate:
- one
- two
- three
